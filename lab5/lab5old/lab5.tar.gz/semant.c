#include <stdio.h>
#include <assert.h>
#include <string.h>
#include "util.h"
#include "errormsg.h"
#include "symbol.h"
#include "absyn.h"
#include "types.h"
#include "env.h"
#include "semant.h"
#include "helper.h"
#include "translate.h"

/*Lab5: Your implementation of lab5.*/

struct expty 
{
	Tr_exp exp; 
	Ty_ty ty;
};

struct expty expTy(Tr_exp exp, Ty_ty ty)
{
	struct expty e;

	e.exp = exp;
	e.ty = ty;

	return e;
}


Ty_ty actual_ty(Ty_ty ty)
{
	while (ty && ty->kind == Ty_name){
		ty = ty->u.name.ty;
	}
	return ty;
}

bool cmpty(Ty_ty ty1,Ty_ty ty2)
{
	Ty_ty actual1 = actual_ty(ty1);
	Ty_ty actual2 = actual_ty(ty2);
	
	if(actual1->kind == actual2->kind) {
		if(actual1->kind == Ty_record) {
			if(actual1->u.record == actual2->u.record) return 1;
			else return 0;
		}
		if (actual1->kind == Ty_array){
			if(actual1->u.array == actual2->u.array) return 1;
			else return 0;
		}
		return 1;
	}
	else {
		if((actual1->kind == Ty_nil && actual2->kind == Ty_record)
			|| (actual1->kind == Ty_record && actual2->kind == Ty_nil))
			return 1;
		else return 0;
	}
}


struct expty transVar(S_table venv, S_table tenv, A_var v, Tr_level l, Temp_label label) {
	switch (v->kind)
	{
	case A_simpleVar:
		return transSimpleVar(venv, tenv, v, l, label);

	case A_subscriptVar:
		return transSubscriptVar(venv, tenv, v, l, label);

	case A_fieldVar:
		return transFieldVar(venv, tenv, v, l, label);

	default:
		assert(0);
	}
}

struct expty transExp(S_table venv, S_table tenv, A_exp a, Tr_level l, Temp_label label) {
	switch(a->kind)
	{
		case A_varExp: 
			return transVar(venv, tenv, a->u.var, l, label);

		case A_nilExp: 
			return expTy(NULL,Ty_Nil());

		case A_intExp: 
			return expTy(NULL,Ty_Int());
		
		case A_stringExp:
			return expTy(NULL,Ty_String());

		case A_callExp:
			return transCallexp(venv, tenv, a, l, label);

		case A_opExp:
			return transOpexp(venv, tenv, a, l, label);

		case A_recordExp:
			return transRecordexp(venv, tenv, a, l, label);

		case A_seqExp:
			return transSeqexp(venv, tenv, a, l, label);

		case A_assignExp:
			return transAssignexp(venv, tenv, a, l, label);

		case A_ifExp:
			return transIfexp(venv, tenv, a, l, label);

		case A_whileExp:
			return transWhileexp(venv,tenv,a, l, label);

		case A_forExp:	
			return transForexp(venv,tenv,a, l, label);

		case A_breakExp:
			return expTy(NULL,Ty_Void());

		case A_letExp:
			return transLetexp(venv,tenv,a, l, label);

		case A_arrayExp:
			return transArrayexp(venv,tenv,a, l, label);

		default:
			assert(0);
	}
}

Tr_exp transDec(S_table venv, S_table tenv, A_dec d, Tr_level l, Temp_label label) {
	switch (d->kind)
	{
	case A_functionDec:
		return transFunctionDec(venv, tenv, d, l, label);
	case A_varDec:
		return transVarDec(venv, tenv, d, l, label);
	case A_typeDec:
		return transTypeDec(venv, tenv, d, l, label);
	default:
		assert(0);
	}
}

Ty_ty		 transTy (              S_table tenv, A_ty a) {

}


struct expty transSimpleVar(S_table venv, S_table tenv, A_var v, Tr_level l, Temp_label label){
	E_enventry sim = S_look(venv, v->u.simple);
	
	if (sim && sim->kind == E_varEntry)
		return expTy(Tr_simpleVar(sim->u.var.access, l), actual_ty(sim->u.var.ty));
	else
		EM_error(v->pos, "undefined variable %s!", S_name(v->u.simple));
	return expTy(NULL, Ty_Int());
}

struct expty transSubscriptVar(S_table venv, S_table tenv, A_var v, Tr_level l, Temp_label label) {

}
struct expty transFieldVar(S_table venv, S_table tenv, A_var v, Tr_level l, Temp_label label) {

}




struct expty transCallexp(S_table venv, S_table tenv, A_exp a, Tr_level l, Temp_label);
struct expty transOpexp(S_table venv, S_table tenv, A_exp a, Tr_level l, Temp_label);
struct expty transRecordexp(S_table venv, S_table tenv, A_exp a, Tr_level l, Temp_label);
struct expty transSeqexp(S_table venv, S_table tenv, A_exp a, Tr_level l, Temp_label);
struct expty transAssignexp(S_table venv, S_table tenv, A_exp a, Tr_level l, Temp_label);
struct expty transIfexp(S_table venv, S_table tenv, A_exp a, Tr_level l, Temp_label);
struct expty transWhileexp(S_table venv, S_table tenv, A_exp a, Tr_level l, Temp_label);
struct expty transForexp(S_table venv, S_table tenv, A_exp a, Tr_level l, Temp_label);
struct expty transLetexp(S_table venv, S_table tenv, A_exp a, Tr_level l, Temp_label);
struct expty transArrayexp(S_table venv, S_table tenv, A_exp a, Tr_level l, Temp_label);




Tr_exp transFunctionDec(S_table venv, S_table tenv, A_dec d, Tr_level l, Temp_label);
Tr_exp transVarDec(S_table venv, S_table tenv, A_dec d, Tr_level l, Temp_label);
Tr_exp transTypeDec(S_table venv, S_table tenv, A_dec d, Tr_level l, Temp_label);



F_fragList SEM_transProg(A_exp exp){

	//TODO LAB5: do not forget to add the main frame
	return NULL;
}

