#include <stdio.h>
#include "util.h"
#include "table.h"
#include "symbol.h"
#include "absyn.h"
#include "temp.h"
#include "tree.h"
#include "printtree.h"
#include "frame.h"
#include "translate.h"

//LAB5: you can modify anything you want.


struct Tr_access_ {
	Tr_level level;
	F_access access;
};
struct Tr_accessList_ {
	Tr_access head;
	Tr_accessList tail;	
};
struct Tr_level_ {
	F_frame frame;
	Tr_level parent;
};
struct patchList_ 
{
	Temp_label *head; 
	patchList tail;
};
struct Cx 
{
	patchList trues; 
	patchList falses; 
	T_stm stm;
};
struct Tr_exp_ {
	enum {Tr_ex, Tr_nx, Tr_cx} kind;
	union {T_exp ex; T_stm nx; struct Cx cx; } u;
};
struct Tr_expList_
{
    Tr_exp head;
    Tr_expList tail;
};

static Tr_exp Tr_Ex(T_exp ex);
static Tr_exp Tr_Nx(T_stm nx);
static Tr_exp Tr_Cx(patchList trues, patchList falses, T_stm stm);

static T_exp unEx(Tr_exp e);
static T_stm unNx(Tr_exp e);
static struct Cx unCx(Tr_exp e);



Tr_expList Tr_ExpList(Tr_exp head, Tr_expList tail) {
	Tr_expList list = (Tr_expList)checked_malloc(sizeof(struct Tr_expList_));
	list->head = head;
	list->tail = tail;
	return list;
}

Tr_access Tr_Access(Tr_level level, F_access access) {
	Tr_access acc = (Tr_access)checked_malloc(sizeof(struct Tr_access_));
	acc->level = level;
	acc->access = access;
	return acc;
}

Tr_accessList Tr_AccessList(Tr_access head, Tr_accessList tail) {
	Tr_accessList list = (Tr_accessList)checked_malloc(sizeof(struct Tr_accessList_));
	list->head = head;
	list->tail = tail;
	return list;
}

static patchList PatchList(Temp_label *head, patchList tail)
{
	patchList list;

	list = (patchList)checked_malloc(sizeof(struct patchList_));
	list->head = head;
	list->tail = tail;
	return list;
}



void doPatch(patchList tList, Temp_label label)
{
	for(; tList; tList = tList->tail)
		*(tList->head) = label;
}

patchList joinPatch(patchList first, patchList second)
{
	if(!first) return second;
	for(; first->tail; first = first->tail);
	first->tail = second;
	return first;
}



static Tr_exp Tr_Ex(T_exp exp) {
	Tr_exp ex = (Tr_exp)checked_malloc(sizeof(ex));
	ex->kind = Tr_ex;
	ex->u.ex = exp;
	return ex;
}

static Tr_exp Tr_Nx(T_stm stm) {
	Tr_exp nx = (Tr_exp)checked_malloc(sizeof(nx));
	nx->kind = Tr_nx;
	nx->u.nx = stm;
	return nx;
}

static Tr_exp Tr_Cx(patchList trues, patchList falses, T_stm stm) {
	Tr_exp cx = (Tr_exp)checked_malloc(sizeof(cx));
	cx->kind = Tr_ex;
	cx->u.cx.trues = trues;
	cx->u.cx.falses = falses;
	cx->u.cx.stm = stm;
	return cx;
}



static T_exp unEx(Tr_exp e) {
	switch (e->kind)
	{
	case Tr_ex:
		return e->u.ex;
	case Tr_nx:
		return T_Eseq(e->u.nx, T_Const(0));
	case Tr_cx:
		Temp_temp r = Temp_newtemp();
		Temp_label t = Temp_newlabel(), f = Temp_newlabel();
		doPatch(e->u.cx.trues, t);
		doPatch(e->u.cx.falses, f);
		return T_Eseq(T_Move(T_Temp(r), T_Const(1)),
						T_Eseq(e->u.cx.stm, 
							T_Eseq(T_Label(f),
								T_Eseq(T_Move(T_Temp(r), T_Const(0)),
									T_Eseq(T_Label(t),
										T_Temp(r))))));
	default:
		assert(0);
	}
}

static T_stm unNx(Tr_exp e) {
	switch (e->kind)
	{
	case Tr_ex:
		return T_Exp(e->u.ex);
	case Tr_nx:
		return e->u.nx;
	case Tr_cx:
		Temp_label l = Temp_newlabel();
		doPatch(e->u.cx.trues, l);
		doPatch(e->u.cx.falses, l);
		return T_Seq(e->u.cx.stm, T_Label(l));
	default:
		assert(0);
	}
}

static struct Cx unCx(Tr_exp e) {
	switch (e->kind)
	{
	case Tr_ex:
		struct Cx cx;
		return cx;
	case Tr_cx:
		return e->u.cx;
	case Tr_nx:
	default:
		assert(0);
	}
}



Tr_exp Tr_simpleVar(Tr_access access, Tr_level level) {
	T_exp frame_ptr = T_Temp(F_FP());
	while (level != access->level) {
		frame_ptr = T_Mem(T_Binop(T_plus, frame_ptr, -wordsize));
		level = level->parent;
	}
	return Tr_Ex(F_accessExp(access, frame_ptr));
}
